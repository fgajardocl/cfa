<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Revolver</title>
    <link id="dynamic-favicon" rel="icon" type="image/png" sizes="64x64" href="img/favicon.png" />
    <link rel="stylesheet" href="css/dpk10.css" />
</head>

<body data-dpk="wrapper">
    <?php include('include/transition.php') ?>
    <?php include('include/menu-desktop.php') ?>

    <main data-dpk="container" data-dpk-namespace="Contact">
        <div data-scroll-container class="bg-black">
            <section data-scroll-section>
                <div class="flex-center position-relative flex-column min-vh-100">
                    <div class="row w-100">
                        <div class="col-xl-6 text-center text-xl-start">
                            <div class="wheel-contact hover-wh">
                                <svg fill="white" class="wheel">
                                    <use xlink:href="img/icon.svg#wheel" />
                                </svg>
                                <h4>CONTACT</h4>
                            </div>
                        </div>
                    </div>

                    <a href="mailto:hello@the-revolvers.com" class="contact-title text-center py-5 pt-xl-0 w-animate">
                        <span>h</span><span>e</span><span>l</span><span>l</span><span>o</span><span>@</span><span>t</span><span>h</span><span>e</span><span>-</span><span>r</span><span>e</span><span>v</span><span>o</span><span>l</span><span>v</span><span>e</span><span>r</span><span>s</span><span>.</span><span>c</span><span>o</span><span>m</span>
                    </a>

                    <br><br><br>

                    <div class="container contact-footer-menu pt-10">
                        <div class="text-center pb-5 text-xl-end">


                            <div class="hover-wheel1 mb-5" data-scroll>
                                <span class="wheel p-2">
                                    <svg fill="#fff" height="7.5rem" width="7.5rem">
                                        <use xlink:href="img/icon.svg#wheel" />
                                    </svg>
                                </span>
        
                                <svg class="rrr" height="3.5rem" width="3.5rem">
                                    <use xlink:href="img/icon.svg#r-black" />
                                </svg>
                            </div>


                        </div>

                        <div class="row">
                            <div class=" pb-3 col-xl-5 order-2 order-xl-1 mt-auto text-center text-xl-start ">
                                <a href="index.php" class="pe-5"> Creativity </a>
                                <a href="index.php" class="pe-5"> Design </a>
                                <a href="#"> Film </a>
                            </div>

                            <div class="pb-3 col-xl-2 order-1 order-xl-2 text-center">
                                <a href="work.php">
                                <div class="scroll-v ps-4" data-scroll>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="pt-1"> WORK </span>
                                </div>
                            </a>
                            </div>

                            <div class=" pb-3 col-xl-5 order-3 order-xl-3 text-xl-end mt-auto text-center ">
                                <a href="index.php" class="pe-5"> Art Direction </a>
                                <a href="index.php" class="pe-5"> Digital </a>
                                <a href="#"> Photography</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <script src="js/bundle.js"></script>
</body>

</html>