
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/bundle.js"></script>

    <?php #wp_print_scripts();?>
</body>

</html>