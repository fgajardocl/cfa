const { gsap } = require("gsap/dist/gsap");
import { closestEdge } from "./Helper";

class MenuItem {
  constructor(el) {
    // .menu__item element
    this.DOM = { el: el };
    // .menu__item-link element
    this.DOM.link = this.DOM.el.querySelector("a.menu__item-link");
    // .marquee element
    this.DOM.marquee = this.DOM.el.querySelector(".marquee");
    // .marquee__inner-wrap element
    this.DOM.marqueeInner = this.DOM.marquee.querySelector(
      ".marquee__inner-wrap"
    );
    // some default options for the animation's speed and easing
    this.animationDefaults = { duration: 0.3, ease: "expo" };
    // events initialization
    this.initEvents();
  }
  initEvents() {
    this.onMouseEnterFn = (ev) => this.mouseEnter(ev);
    this.DOM.link.addEventListener("mouseenter", this.onMouseEnterFn);
    this.onMouseLeaveFn = (ev) => this.mouseLeave(ev);
    this.DOM.link.addEventListener("mouseleave", this.onMouseLeaveFn);
  }
  mouseEnter(ev) {
    // find closest side to the mouse
    const edge = this.findClosestEdge(ev);

    // set the initial y position for both the marquee and marqueeInner elements
    // for the reveal effect to happen, both start at opposite positions
    // the directions are different depending on the direction the cursor enters the element (bottom or top)
    gsap
      .timeline({ defaults: this.animationDefaults })
      .set(this.DOM.marquee, { y: edge === "top" ? "-101%" : "101%" }, 0)
      .set(this.DOM.marqueeInner, { y: edge === "top" ? "101%" : "-101%" }, 0)
      .to([this.DOM.marquee, this.DOM.marqueeInner], { y: "0%" }, 0);
  }
  mouseLeave(ev) {
    // find closest side to the mouse
    const edge = this.findClosestEdge(ev);

    gsap
      .timeline({ defaults: this.animationDefaults })
      .to(this.DOM.marquee, { y: edge === "top" ? "-101%" : "101%" }, 0)
      .to(this.DOM.marqueeInner, { y: edge === "top" ? "101%" : "-101%" }, 0);
  }
  // find closest side to the mouse when entering/leaving
  findClosestEdge(ev) {
    const x = ev.pageX - this.DOM.el.offsetLeft;
    const y = ev.pageY - this.DOM.el.offsetTop;
    return closestEdge(x, y, this.DOM.el.clientWidth, this.DOM.el.clientHeight);
  }
}

class Menu {
  constructor(el) {
    // .menu element
    this.DOM = { el: el };
    // the menu items
    this.DOM.menuItems = this.DOM.el.querySelectorAll(".menu__item");
    // array of MenuItem
    this.menuItems = [];
    this.DOM.menuItems.forEach((menuItem) =>
      this.menuItems.push(new MenuItem(menuItem))
    );
  }
}























function loaderAni() {
  const tl = gsap.timeline();

  tl.to(".loader_inner", {
    y: -300,
    opacity: 0,
    duration: 0.5,
    ease: "expo.inOut",
    delay: 3,
  });
  tl.set(".img-white",{opacity:0})
  tl.set(".img-black",{opacity:1})



  tl.to(".loader", {
    scaleY: 0,
    duration: 0.8,
    ease: "expo.out",
    transformOrigin: "top",
    delay: 0.2,
  });

 
  



  tl.to(
    ".white-layer",
    {
      scaleY: 0,
      duration: .7,
      ease: "power3.out",
      transformOrigin: "top",
      delay: .7,
      onComplete: whLayer
    }
  );
  tl.to(".img-black",{opacity:0, duration:.05},"<+.3")
  tl.to(".img-white",{opacity:1 , duration:.1},"<-.15")

 

}



const phrases = [
  "Creativity",
  "Design",
  "Art Direction",
  "Digital",
  "Photography",
];

let demo = document.querySelector(".demo");
let animation = gsap.timeline({ repeat: 2, repeatDelay: 0.15 });

function createLayers() {
  phrases.forEach((value) => {
    let layer = document.createElement("div");
    layer.innerHTML = value;
    demo.appendChild(layer);
  });
}

function animateText() {
  let layers = document.querySelectorAll(".demo div");
  layers.forEach(function (element, index) {
    animation.fromTo(
      element,
      { opacity: 0 },
      {
        opacity: 1,
        repeat: 1,
        duration: .15,
        yoyo: true,
      }
    );
  });
  gsap.set(".demo", { visibility: "visible" });
}

createLayers();
animateText();



function whLayer() {
  const imgTitle = document.querySelector(".img-white")

  const tl = gsap.timeline({ paused: true });
  tl.to(
    ".white-layer",
    {
      scaleY: 1,
      duration: .5,
      ease: "power3.in",
      transformOrigin: "bottom",
    }
  );

  tl.to(
    ".white-layer",
    {
      scaleY: 0,
      duration: .7,
      ease: "power3.out",
      transformOrigin: "top",
    }
  );


  if (imgTitle) {
    imgTitle.addEventListener("mouseenter", function () {
      tl.play()
    })

    imgTitle.addEventListener("mouseleave", function () {
      setTimeout(() => {
        tl.reverse();
      }, 500);
    })
  }


}



function closeLayer() {
  gsap.to(
    ".white-layer",
    {
      scaleY: 0,      
      ease: "power3.out",
      transformOrigin: "top",
      // delay: .2,
      onComplete: whLayer
    }
  );
}


export { Menu, loaderAni, closeLayer };