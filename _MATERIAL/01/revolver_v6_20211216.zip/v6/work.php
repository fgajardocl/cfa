<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Revolver</title>
    <link id="dynamic-favicon" rel="icon" type="image/png" sizes="64x64" href="img/favicon.png" />
    <link rel="stylesheet" href="css/dpk10.css" />
</head>

<body data-dpk="wrapper">
    <?php include('include/transition.php') ?>
    <?php include('include/menu-desktop.php') ?>

    <main data-dpk="container" data-dpk-namespace="Home">
        <div data-scroll-container class="bg-black">
            <section data-scroll-section>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1">
                            <h1 class="work-title w-animate">
                                <span>W</span><span class="sky-blue">Ø</span><span>R</span><span>K</span>
                            </h1>

                            <p class="g-bold work-desc m-animate text-justufy ps-xl-4">
                                Una selección de los mejores trabajos que hemos realizado para
                                nuestros clientes. Un proceso al que nos gusta dedicar tiempo
                                y perfección en cada detalle.
                            </p>

                            <a href="#here" data-scroll-to class="flex-center pt-10 pb-xl-5 m-animate">
                                <div class="hover-wheel1 mb-5" data-scroll>
                                    <span class="wheel p-2">
                                        <svg fill="#fff" height="10rem" width="10rem">
                                            <use xlink:href="img/icon.svg#wheel" />
                                        </svg>
                                    </span>

                                    <svg class="rrr" height="5rem" width="5rem">
                                        <use xlink:href="img/icon.svg#r-black" />
                                    </svg>
                                </div>


                                <div class="scroll-v ml-5" data-scroll>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke"></span>

                                </div>
                            </a>

                            <br><br>

                            <div class="row work-info pb-5 pt-12" id="here">
                                <div class="col-xl-4 text-xl-end my-auto pb-xl-0 pb-4">
                                    <h4 class="appear-y" data-scroll>
                                        <span class="sky-blue">smarty</span>car/
                                    </h4>
                                </div>
                                <div class="col-xl-8 ps-xl-5">
                                    <p class="g-light appear-y text-justufy" data-scroll>
                                        Para nuestro cliente SmartyCar, trabajamos en el
                                        lanzamiento de marca desde el proceso de estrategia, la
                                        creatividad, producción y filmación de la campaña. Un
                                        trabajo integrado como estudio creativo.
                                    </p>
                                </div>
                            </div>

                            <img src="./img/work/6.jpg" alt="" data-scroll class="appear-y img-fluid py-4" />

                            <div class="row appear-y" data-scroll data-scroll-offset="20%">
                                <div class="col-3">
                                    <img src="./img/work/7.jpg" alt="" class="img-fluid" />
                                </div>
                                <div class="col-3">
                                    <img src="./img/work/8.jpg" alt="" class="img-fluid" />
                                </div>
                                <div class="col-3">
                                    <img src="./img/work/9.jpg" alt="" class="img-fluid" />
                                </div>
                                <div class="col-3">
                                    <img src="./img/work/7.jpg" alt="" class="img-fluid" />
                                </div>
                            </div>

                            <div class="d-flex justify-content-end pb-5 mt-3">
                                <svg class="work-wheel-2">
                                    <use xlink:href="img/icon.svg#wheel" />
                                </svg>

                                <div class="scroll-v">
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="pt-1"> WORK </span>
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section data-scroll-section>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1">
                            <div class="row work-info pb-5">
                                <div class="col-xl-4 text-xl-end my-auto pb-xl-0 pb-4">
                                    <h4 class="appear-y" data-scroll>
                                        <span class="sky-blue">smarty</span>car/
                                    </h4>
                                    <h6 class="appear-y ps-2" data-scroll class="g-bold-italic">
                                        -PreRoll - Stories -Posts - Gráfica
                                    </h6>
                                </div>
                                <div class="col-xl-8 ps-xl-5">
                                    <p class="appear-y text-justufy" data-scroll>
                                        Como parte de la misma campaña “Comprar un auto no es
                                        Smarty” creamos una idea para los formatos PreRoll y
                                        Bumper de Youtube. Además de Post, Stories, Pantallas en
                                        Vía Pública y Gráfica
                                    </p>
                                </div>
                            </div>

                            <div data-scroll class="appear-y lazy-wrapper mb-4">
                                <img class="lazy" data-src="./img/work/car.jpg" />
                            </div>

                            <div class="d-flex justify-content-end pb-5">
                                <svg class="work-wheel-2">
                                    <use xlink:href="img/icon.svg#wheel" />
                                </svg>

                                <div class="scroll-v">
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="pt-1"> WORK </span>
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section data-scroll-section>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1">
                            <div class="row work-info pb-5">
                                <div class="col-xl-4 text-xl-end my-auto pb-xl-0 pb-4">
                                    <h4 class="appear-y" data-scroll>
                                        <span class="sky-blue">Mobil</span>/
                                    </h4>
                                    <h6 class="appear-y" data-scroll class="g-bold-italic">
                                        Fotografía + Retoque
                                    </h6>
                                </div>
                                <div class="col-xl-8 ps-xl-5">
                                    <p class="appear-y text-justufy" data-scroll>
                                        Junto a nuestro socio AGUAYO ESTUDIO realizamos esta
                                        producción fotográfica para una campaña de Mob de la
                                        agencia Kinder Lab. El retoque estuvo a cargo de nuestro
                                        querido Gonzalo Arévalo.
                                    </p>
                                </div>
                            </div>

                            <div data-scroll class="appear-y lazy-wrapper mb-6">
                                <img class="lazy" data-src="./img/work/1.jpg" />
                            </div>

                            <div data-scroll class="appear-y lazy-wrapper mb-6">
                                <img class="lazy" data-src="./img/work/2.jpg" />
                            </div>

                            <div class="d-flex justify-content-end pb-5">
                                <svg class="work-wheel-2">
                                    <use xlink:href="img/icon.svg#wheel" />
                                </svg>

                                <div class="scroll-v">
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="pt-1"> WORK </span>
                                </div>



                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section data-scroll-section>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1 work-info">
                            <div class="d-flex align-items-center pb-4">
                                <h4 class="pe-4 pe-xl-5">
                                    GreenPeace/
                                    <span> Ads</span>
                                </h4>

                                <svg height="5rem" width="5.5rem">
                                    <use xlink:href="img/icon.svg#w1" />
                                </svg>
                                <svg height="5rem" width="5.5rem">
                                    <use xlink:href="img/icon.svg#w2" />
                                </svg>
                                <svg height="5rem" width="5.5rem">
                                    <use xlink:href="img/icon.svg#w3" />
                                </svg>
                            </div>
                            <p class="pb-5 text-justufy">
                                Junto a McCANN trabajamos desde la dirección de arte hasta la
                                producción final. Cuidando todos los detalles que merece una
                                idea tan potente y provocativa como ésta. Sabíamos que tenía
                                que verse lo más real posible por lo que estudiamos el tiempo
                                de las botellas en el mar y ríos, construimos un acuario en el
                                estudio y terminamos haciendo el desgaste y maquillando cada
                                botella con un artista especialista. La campaña fue finalista
                                en Cannes, ganó un sol de Bronce en el festival de San
                                Sebastián y fue seleccionada en Lüerzers Archive.
                            </p>

                            <div data-scroll class="appear-y lazy-wrapper mb-6">
                                <img class="lazy" data-src="./img/work/3.jpg" />
                            </div>

                            <div data-scroll class="appear-y lazy-wrapper mb-6">
                                <img class="lazy" data-src="./img/work/4.jpg" />
                            </div>

                            <div data-scroll class="appear-y lazy-wrapper mb-6">
                                <img class="lazy" data-src="./img/work/5.jpg" />
                            </div>
                        </div>
                    </div>
                </div>
                <?php include('./include/footer-for-work.php') ?>

            </section>
        </div>
    </main>

    <script src="js/bundle.js"></script>
</body>

</html>