<div class="modulo_texto_libre">
    <div class="wrap">
        <div class="cont <?php the_sub_field('ancho_maximo');?>"><?php the_sub_field('texto');?></div>
    </div>
</div>