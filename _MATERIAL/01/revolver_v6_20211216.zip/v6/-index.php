<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Revolver</title>
    <link id="dynamic-favicon" rel="icon" type="image/png" sizes="64x64" href="img/favicon.png" />
    <link rel="stylesheet" href="css/dpk10.css" />
</head>

<body data-dpk="wrapper">
    <?php include('include/transition.php') ?>
    <?php include('include/menu-desktop.php') ?>

    <main data-dpk="container" data-dpk-namespace="Home">
        <div data-scroll-container class="bg-black">
            <section data-scroll-section class="position-relative wh-layer">
                <div class="white-layer"></div>
                <a href="#here" data-scroll-to>
                    <div class="container home-img vh-100">
                        <img class="img-white" src="./img/revolver.svg" alt="">
                        <img class="img-black" src="./img/black.svg" alt="">
                    </div>
                </a>

                <div class="container m-animate contact-footer-menu mixblend pt-10">
                    <div class="row">

                        <div class="pb-4 pb-md-3 col-xl-5 order-2 order-xl-1 mt-auto text-center text-xl-start ">
                            <a href="work.php">
                                <span class="pe-5"> Creativity </span>
                                <span class="pe-5"> Design </span>
                                <span> Film </span>
                            </a>
                        </div>

                        <div class="pb-4 pb-md-3 col-xl-2 order-1 order-xl-2 text-center">
                            <a href="#here" data-scroll-to>
                                <div class="scroll-v" data-scroll>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="add-stroke">V</span>
                                    <span class="pt-1"> WORK </span>
                                </div>
                            </a>
                        </div>

                        <div class=" pb-4 pb-md-3 col-xl-5 order-3 order-xl-3 text-xl-end mt-auto text-center">
                            <a href="work.php">
                                <span class="pe-5"> Art Direction </span>
                                <span class="pe-5"> Digital</span>
                                <span> Photography</span>
                            </a>
                        </div>
                    </div>
                </div>


            </section>

            <section data-scroll-section id="here">
                <div class="flex-center pt-7">
                    <div class="hover-wheel1 mb-5" data-scroll>
                        <span class="wheel p-2">
                            <svg fill="#fff" height="10rem" width="10rem">
                                <use xlink:href="img/icon.svg#wheel" />
                            </svg>
                        </span>

                        <svg class="rrr" height="5rem" width="5rem">
                            <use xlink:href="img/icon.svg#r-black" />
                        </svg>
                    </div>
                </div>




                <div class="marq">
                    <div class="track">
                        <h5 class="content">&nbsp;
                            New Work <spam class="add-stroke px-3 ">New Work</spam>
                            New Work <spam class="add-stroke px-3 ">New Work</spam>
                            New Work <spam class="add-stroke px-3 ">New Work</spam>
                            New Work <spam class="add-stroke px-3 ">New Work</spam>
                            New Work <spam class="add-stroke px-3 ">New Work</spam>

                        </h5>
                    </div>
                </div>




                <div class="flex-center pt-5">
                    <h1 class="add-stroke title-2" data-scroll-speed="-4" data-scroll-deay=".05" data-scroll
                        data-scroll-direction="horizontal">
                        CREATIVITY
                    </h1>
                </div>
                <div class="container">
                    <img src="./img/work/6.jpg" alt="" class="img-fluid" />
                </div>


                <?php include('./include/footer.php') ?>
            </section>
        </div>
    </main>

    <script src="js/bundle.js"></script>
</body>

</html>