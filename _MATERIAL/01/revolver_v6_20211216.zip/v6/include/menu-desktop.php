<header class="container">
  <div class="row">
    <div class="col-6 col-xl-2 col-md-3">
      <a class="headerLink" href="index.php"> REVØLVER </a>
    </div>
    <div class="col-xl-10 col-md-9 col-6 d-flex justify-content-between pe-0 fs-4">
      <span class="ham ms-auto ms-md-0">MENU</span>
      <a class="h-sm ps-5 headerLink" href="contact.php" class="pe-5">CONTACT</a>
    </div>
  </div>
</header>

<div class="menu-wrap">
  <nav class="menu">
    <!-- revolver -->
    <div class="menu__item">
      <a class="menu__item-link" href="about.php">REVØLVER</a>

      <div class="marquee">
        <div class="marquee__inner-wrap">
          <div class="marquee__inner" aria-hidden="true">
            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>REVØLVER</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>

            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>REVØLVER</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Work -->
    <div class="menu__item">
      <a class="menu__item-link" href="work.php">WORK</a>

      <div class="marquee">
        <div class="marquee__inner-wrap">
          <div class="marquee__inner" aria-hidden="true">
            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>WORK</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>

            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>WORK</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- client -->
    <div class="menu__item">
      <a class="menu__item-link" href="client.php">CLIENTS</a>

      <div class="marquee">
        <div class="marquee__inner-wrap">
          <div class="marquee__inner" aria-hidden="true">
            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>CLIENTS</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>

            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>CLIENTS</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- client -->
    <div class="menu__item">
      <a class="menu__item-link" href="contact.php">CONTACT</a>

      <div class="marquee">
        <div class="marquee__inner-wrap">
          <div class="marquee__inner" aria-hidden="true">
            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>CONTACT</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>

            <span class="add-stroke">VER</span>
            <div class="marquee__img" style="background-image: url(img/1.jpg)"></div>
            <span class="add-stroke">VER</span>

            <div class="marquee__img" style="background-image: url(img/2.jpg)"></div>
            <span>CONTACT</span>
            <div class="marquee__img" style="background-image: url(img/3.jpg)"></div>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <div class="container text-white contact-footer-menu pt-10">
    <div class="row">
      <div class="
          pb-3
          col-xl-5
          order-2 order-xl-1
          mt-auto
          text-center text-xl-start
        ">
        <a href="index.php" class="pe-5"> Creativity </a>
        <a href="index.php" class="pe-5"> Design </a>
        <a href="#"> Film </a>
      </div>

      <div class="pb-3 col-xl-2 order-1 order-xl-2 text-center">
        <a href="work.php" class="scroll-m ps-4">
          <span class="add-stroke">V</span>
          <span class="add-stroke">V</span>
          <span class="add-stroke">V</span>
          <span class="pt-1"> WORK </span>
        </a>
      </div>

      <div class="pb-3 col-xl-5 order-3 order-xl-3 text-xl-end mt-auto text-center">
        <a href="index.php" class="pe-4"> Art Direction </a>
        <a href="index.php" class="pe-4"> Digital </a>
        <a href="#"> Photography</a>
      </div>
    </div>
  </div>
</div>  