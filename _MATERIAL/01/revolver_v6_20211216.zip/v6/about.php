<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Revolver</title>
    <link id="dynamic-favicon" rel="icon" type="image/png" sizes="64x64" href="img/favicon.png" />
    <link rel="stylesheet" href="css/dpk10.css" />
</head>

<body data-dpk="wrapper">
    <?php include('include/transition.php') ?>
    <?php include('include/menu-desktop.php') ?>

    <main data-dpk="container" data-dpk-namespace="Home">
        <div data-scroll-container class="bg-white">
            <section data-scroll-section>
                <div class="container pt-top pb-10">
                    <div class="row">
                        <div class="col-md-10 offset-md-1">
                            <h1 class="home-title w-animate"><span>R</span><span>E</span><span>V</span><span>Ø</span><span>L</span><span>V</span><span>E</span><span>R</span></h1>

                            <p class="home-info p-md-4 m-animate  text-justufy">
                                Somos un estudio creativo y nuestro ADN es buscar siempre una
                                perspectiva única para una idea, desde el crafting y forma
                                para comunicar. Investigar caminos diferentes para llegar a un
                                resultado inesperado y conectar con una idea que provoque y
                                sorprenda. Trabajamos para marcas y agencias que bus can
                                potenciar su contenido creativo y negocio.
                            </p>




                            <div class="d-flex pt-5 align-content-center justify-content-end m-animate mx-95">
                                <h4 class="fs-3 my-auto pe-8">CONTACT</h4>

                                <div class="hover-wheel1" data-scroll>
                                    <span class="wheel p-2">
                                        <svg fill="#000" height="7.5rem" width="7.5rem">
                                            <use xlink:href="img/icon.svg#wheel" />
                                        </svg>
                                    </span>
            
                                    <svg class="rrr" height="3.5rem" width="3.5rem">
                                        <use xlink:href="img/icon.svg#r-white" />
                                    </svg>
                                </div>

                               
                            </div>


                          
                            <div class="row pt-top">
                                <div class="col-xl-7 pe-xl-5">
                                    <img src="./img/man.jpg" alt="" class="img-fluid" />
                                </div>

                                <div class="col-xl-4 mt-auto pt-5 pt-xl-0 home-2">
                                    <h2 class="fs-4 text-md-end appear-title" data-scroll>
                                        <span class="appears-dpk ms-auto"> <span> RENZO </span></span>
                                        <span class="appears-dpk ms-auto"> <span> VACARISAS </span></span>
                                        <span class="appears-dpk ms-auto"> <span> SOLARI</span></span>
                                    </h2>

                                    <h5 class="fs-3 pt-4 pb-5 text-md-end appear-y" data-scroll>
                                        Fundador y <br />
                                        Director General Creativo
                                    </h5>

                                    <p class="g-bold ps-xl-6 appear-y text-justufy" data-scroll>
                                        Publicista, con un post grado en Roger Hatchuel Academy de
                                        Cannes 2005, Francia. Ha trabajado como director creativo
                                        en agencias como PJ&D y McCANN. En está última fue elegido
                                        como mejor profesional del año el 2019. Con más de 15 años
                                        de experiencia en la industria y en agencias ha sido
                                        reconocido en importantes festivales de creatividad como:
                                        Cannes Lions, El Ojo de Iberoamérica, El Sol de San
                                        Sebastián, Wave Festival Brasil, Achap, Effie LATAM, Effie
                                        Chile y seleccionado en Lüerzers Archive. Ha trabajado
                                        para importantes marcas como Ripley, Entel, Coca-Cola,
                                        Rotter&Krauss, SmartyCar, Super Cerdo, CDF, Greenpeace y
                                        Master Card entre otras.
                                    </p>
                                </div>

                                

                                <a href="#here" data-scroll-to class="scroll-v pt-5" data-scroll  >
                                    <span class="fww">V</span>
                                    <span class="fww">V</span>
                                    <span class="fww">V</span>
                                    <span class="pt-1">Forma de trabajo</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section data-scroll-section class="bg-black min-vh-100 pt-top">
                <div class="container" id="here">
                    <div class="row">
                        <div class="offset-xl-1 col-xl-5 pb-5">
                            <h3 class="s2-title-1 text-center appear-title" data-scroll data-scroll-offset="10%">
                                <span class="appears-dpk mx-auto"> <span> IDEAS </span></span>
                                <span class="appears-dpk mx-auto">
                                    <span class="add-stroke"> CREATIVITY </span></span>
                                <span class="appears-dpk mx-auto">
                                    <span> DESIGN </span></span>
                                <span class="appears-dpk mx-auto"> <span class="sky-blue"> FILM </span></span>
                            </h3>

                            <h3 class="s2-title-1 offset-xl-6 appear-title" data-scroll data-scroll-offset="10%">
                                <span class="appears-dpk"> <span> DIGITAL </span></span>
                                <span class="appears-dpk"> <span> ART DIRECTION </span></span>
                            </h3>

                            <h3 class="s2-title-1 offset-xl-3 appear-title ps-md-4" data-scroll
                                data-scroll-offset="10%">
                                <span class="appears-dpk"> <span> PHOTOGRAPHY </span></span>
                            </h3>

                          


                        </div>
                        <div class="offset-xl-1 col-xl-4">
                            <p class="s2-info py-3 ps-xl-5 ps-4 appear-y text-justufy" data-scroll>
                                Creemos que la verdadera forma de poder crear algo es
                                involucrandose en todas las etapas del proceso creativo.
                                <br /><br />
                                Estamos en todo lo que hacemos desde la idea escrita o
                                dibujada en el papel hasta la producción y ejecución.

                                <br /><br />
                                Es la única forma de dejar nuestro sello en el trabajo que
                                hacemos día a día. No soltar nada. Es por esa razón que
                                abarcamos diferentes áreas de comunicación.
                            </p>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end me-5 ">
                        <svg class="fill-wh me-md-5">
                            <use xlink:href="img/icon.svg#wheel-r" />
                        </svg>
                   </div>



                    <div class="row pt-15" >
                        <div class="col-10 offset-1">
                            <img data-scroll src="./img/about/1.jpg" alt="" class="img-fluid pb-5 appear-y" />
                            <img data-scroll src="./img/about/2.jpg" alt="" class="img-fluid pb-5 appear-y" />
                            <img data-scroll src="./img/about/3.jpg" alt="" class="img-fluid pb-5 appear-y" />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-5 offset-1">
                            <img src="./img/about/4.jpg" alt="" data-scroll class="appear-y img-fluid pb-5 pe-5" />
                        </div>
                        <div class="col-5">
                            <div class="h-sm pt-15"></div>
                            <img src="./img/about/5.jpg" alt="" data-scroll class="appear-y img-fluid pb-5" />
                        </div>
                    </div>

                    <div class="row img-grid">
                        <div class="col-6 offset-1">
                            <img src="./img/about/6.jpg" alt="" data-scroll class="appear-y img-fluid pb-4" />
                        </div>
                        <div class="col-4">
                            <img src="./img/about/7.jpg" alt="" data-scroll class="appear-y img-fluid pb-4" />
                            <img src="./img/about/8.jpg" alt="" data-scroll class="appear-y img-fluid pb-4" />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-5 offset-1">
                            <img src="./img/about/9.jpg" alt="" data-scroll class="appear-y img-fluid" />
                        </div>
                        <div class="col-5">
                            <img src="./img/about/10.jpg" alt="" data-scroll class="appear-y img-fluid" />
                        </div>
                    </div>
                </div>

                <footer class="pt-10 spin-this" data-scroll>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 offset-md-1">
                                <a href="work.php">
                                <h3 class="footer-title text-center d-inline-block appear-title" data-scroll
                                    data-scroll-offset="20%">
                                    <span class="appears-dpk mx-auto">
                                        <span> IDE<b class="add-stroke">A</b>S </span></span>
                                    <span class="appears-dpk mx-auto">
                                        <span class="add-stroke"> CREATIVITY </span></span>
                                    <span class="appears-dpk mx-auto">
                                        <span> DESIGN </span></span>
                                    <span class="appears-dpk mx-auto">
                                        <span class="sky-blue"> FILM </span></span>
                                </h3>
                                <h3 class="footer-title appear-title offset-xl-2" data-scroll data-scroll-offset="20%">
                                    <span class="appears-dpk"> <span> DIGITAL </span></span>
                                    <span class="appears-dpk">
                                        <span class="add-stroke"> ART DIRECTION </span></span>
                                </h3>

                                <h3 class="footer-title ps-md-4 appear-title offset-xl-1" data-scroll
                                    data-scroll-offset="20%">
                                    <span class="appears-dpk"> <span> PHOTOGRAPHY </span></span>

                                </h3>

                            </a>
                            </div>
                            <div class="col-md-4 text-center pt-5 pt-md-0 text-md-end">
                                <a href="work.php" class="footer-ver">
                                    <svg fill="#c1c1c1" height="15rem" width="15rem">
                                        <use xlink:href="img/icon.svg#wheel" />
                                    </svg>
                                    <span class="g-bold home">
                                        ver <br />
                                        trabajos</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <?php include('./include/footer-menu.php') ?>
                </footer>
            </section>
        </div>
    </main>

    <script src="js/bundle.js"></script>
</body>

</html>