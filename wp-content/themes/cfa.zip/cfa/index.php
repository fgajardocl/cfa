
<?php get_header(); ?>


<?php
echo get_post_type();
?>

<?php get_footer();