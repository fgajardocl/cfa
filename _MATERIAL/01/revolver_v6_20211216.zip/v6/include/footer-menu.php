<div class="container footer-menu pt-10">
  <div class="row">
    <div class="col-4 mt-auto">
      <a href="index.php" class="pe-5"> REVØLVER </a>
      <!-- <a class="h-sm ham" href="#"> MENU </a> -->
    </div>

    <div class="col-4 text-md-center text-end">
      <a href="index.php">
        <svg height="5rem">
          <use xlink:href="img/icon.svg#r-black" />
        </svg>
      </a>
    </div>

    <div class="col-4 text-end mt-auto">
      <a class="h-sm" href="contact.php"> CONTACT </a>
    </div>
  </div>
</div>