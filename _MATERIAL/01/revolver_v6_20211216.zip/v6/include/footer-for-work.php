<footer>
    <div class="container spin-this" data-scroll>
        <div class="row el-studio">
            <div class="col-md-8">
                <a href="about.php" class="scroll-v" data-scroll>
                    <span class="add-stroke">V</span>
                    <span class="add-stroke">V</span>
                    <span class="add-stroke">V</span>
                    <span class="pt-1"> </span>
                </a>
                <a href="about.php">
                    <h4 class="appear-title" data-scroll data-scroll-offset="10%">
                        <span class="appears-dpk"> <span> We are </span> </span>
                        <span class="appears-dpk el-2"> <span> REVØLVER </span> </span>
                    </h4>
                </a>
            </div>

            <div class="col-md-4 pt-5 pt-md-0 text-end">
                <a href="about.php" class="footer-ver m-negative">
                    <svg fill="#c1c1c1">
                        <use xlink:href="img/icon.svg#wheel" />
                    </svg>
                    <span class="g-bold work-footer-text">
                        ver +
                    </span>
                </a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <a href="index.php">
                <h3 class="footer-title text-center d-inline-block appear-title" data-scroll data-scroll-offset="20%">
                    <span class="appears-dpk mx-auto"> <span> IDE<b class="add-stroke">A</b>S  </span></span>
                    <span class="appears-dpk mx-auto">
                        <span class="add-stroke"> CREATIVITY </span></span>
                    <span class="appears-dpk mx-auto"> <span> DESIGN </span></span>
                    <span class="appears-dpk mx-auto">
                        <span class="sky-blue"> FILM </span></span>
                </h3>
                <h3 class="footer-title appear-title offset-xl-2 ps-md-4" data-scroll data-scroll-offset="20%">
                    <span class="appears-dpk"> <span> DIGITAL </span></span>
                    <span class="appears-dpk"> <span class="add-stroke"> ART DIRECTION </span></span>
                </h3>

                <h3 class="footer-title ps-md-4 appear-title offset-xl-1" data-scroll data-scroll-offset="20%">
                    <span class="appears-dpk"> <span> PHOTOGRAPHY </span></span>
                </h3>
            </a>
            </div>
        </div>
    </div>

    <div class="container footer-menu pt-10">
        <div class="row">
            <div class="col-md-4 col-6 mt-auto order-2 order-md-1">
                <a href="index.php" class="pe-5"> REVØLVER </a>
            </div>

            <div class="col-md-4 col-12 text-center order-1 order-md-2">
                <a href="index.php">
                    <svg height="4.5rem">
                        <use xlink:href="img/icon.svg#r-black" />
                    </svg>
                </a>
            </div>

            <div class="col-md-4 col-6 text-end mt-auto order-3 order-md-3">
                <a href="contact.php"> CONTACT </a>
            </div>
        </div>
    </div>
</footer>