<div class="modulo_texto_imagen" style="background-image:url(<?php the_sub_field('imagen_fondo');?>)">
    <div class="wrap">
        <div class="cont <?php the_sub_field('posicion_texto');?>">
            <div><?php the_sub_field('contenido');?></div>
        </div>
    </div>
</div>