
<section data-scroll-section class="nosotros-page _desk" style="background-image: url('<?php the_sub_field('imagen_desk')?>')"></section>
<section data-scroll-section class="nosotros-page _mov" style="background-image: url('<?php the_sub_field('imagen_mobile')?>')"></section>
