import barba from "@barba/core";
import barbaPrefetch from "@barba/prefetch";
import LazyLoad from "vanilla-lazyload";
import { signature } from "./Module/Helper";

// signature();

import {
  dpkCursor,
  initCursor,
  resetCursor,
  cursorEffects,
} from "./Module/dpkCursor";
import { scroll, smooth } from "./Module/loco";
import { Menu, closeLayer, loaderAni } from "./Module/menu";

const { gsap } = require("gsap/dist/gsap");









const ham = document.querySelector(".ham");
const menu = document.querySelector(".menu-wrap");
const headerLink = document.querySelectorAll(".headerLink");
const menulinks = menu.querySelectorAll(".menu__item");

menulinks.forEach((link) => {
  link.addEventListener("click", function () {
    tl.reverse();
  });
});


headerLink.forEach((link) => {
  link.addEventListener("click", function () {
    tl.reverse();
  });
});


const tl = gsap.timeline({ paused: true });

tl.to(menu, {
  scaleY: 1,
  ease: "expo.inOut",
  duration: .4
});

tl.from(".menu__item", {
  opacity: 0,
  yPercent: 110,
  stagger: 0.06,
});

tl.from(".menu-wrap .contact-footer-menu .pb-3 ", {
  opacity: 0,
  duration: 0.3,
  yPercent: 110,
  stagger: 0.02,
});

tl.reverse();

ham.addEventListener("click", () => {
  tl.reversed(!tl.reversed());
});







/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    invokded Once 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

initCursor();
new Menu(document.querySelector(".menu"));

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
              Prevent Reload On Same Page 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

let pagelinks = document.querySelectorAll("header a[href] , .menu a[href]");
const preventReload = function (e) {
  if (e.currentTarget.href === window.location.href) {
    e.preventDefault();
    e.stopPropagation();
    scroll.scrollTo(0);
    tl.reverse();

    
  }
};

for (let i = 0; i < pagelinks.length; i++) {
  pagelinks[i].addEventListener("click", preventReload);
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        LazyLoad
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

function lazy_load() {
  const lazyLoadInstance = new LazyLoad({
    elements_selector: ".lazy",
    thresholds: "100% 800px",
  });
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            Barba init on [Once & Before enter]
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

function init() {
  window.scrollTo(0, 0);
  gsap.from(".scroll-v .add-stroke",{ y:-10, opacity:0, stagger:.1, repeat:-1,repeatDelay:.3})
  gsap.from(".scroll-v .fww",{ y:-10, opacity:0, stagger:.1, repeat:-1,repeatDelay:.3})
  resetCursor();
  lazy_load();
  setTimeout(() => {
    cursorEffects();
   
    gsap.from(".m-animate", {
      autoAlpha: 0,
      y: 70,
      duration: 0.6,
      opacity: 0,
      stagger: 0.2,
    });

    gsap.from(".w-animate span", {
      autoAlpha: 0,
      opacity: 0,
      stagger: 0.1,
      ease:"none"
    });

    


  }, 1100);
  
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                 Barba Js
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

barba.use(barbaPrefetch);
import { appears, disappears } from "./Module/barbaHelper";

barba.init({
  schema: { prefix: "data-dpk" },
  debug: true,
  timeout: 5000,
  preventRunning: true,

  transitions: [
    {
      name: "dpk-transition",
      once({ next }) {
        smooth(next.container);
        init();
        loaderAni();
      },

      async leave(data) {
        const done = this.async();
        disappears(data.current.container, 0.8, done);
        scroll.destroy();
      },

      beforeEnter({ next }) {
        smooth(next.container);
        init();
        scroll.stop();
      },

      enter({ next }) {
        appears(next.container, 0.8);
        setTimeout(() => {
          scroll.start();
          closeLayer();
        }, 1000);
      },
    },
  ],
});
