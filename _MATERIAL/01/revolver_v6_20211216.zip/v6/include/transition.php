<div class="loader">
  <div class="loader_inner">
    <h2 class="text-white">REVØLVER</h2>
    <div class="demo"></div>
  </div>
</div>
