<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Revolver</title>
    <link id="dynamic-favicon" rel="icon" type="image/png" sizes="64x64" href="img/favicon.png" />
    <link rel="stylesheet" href="css/dpk10.css" />
</head>

<body data-dpk="wrapper">
    <?php include('include/transition.php') ?>
    <?php include('include/menu-desktop.php') ?>
     

    <main data-dpk="container" data-dpk-namespace="Clients">
        <div data-scroll-container class="bg-white">
            <section data-scroll-section class="min-vh-100">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1">
                            <h1 class="client-title text-center w-animate"><span>C</span><span>L</span><span>I</span><span>E</span><span>N</span><span>T</span><span>S</span></h1>

                            <p class="g-bold work-desc mx-80 m-animate text-justufy">
                                Cuando te eligen, es porque están confiando en las personas
                                que están ayudando a construir una marca, nos gusta ver a nuestros
                                clientes como un solo equipo en ese proceso de construcción.
                            </p>


                            <div class="row appear-y" data-scroll>
                                <div class="flex-center client-svg">
                                   
                                    <svg class="img-fluid p-4">
                                        <use xlink:href="img/icon.svg#client2" />
                                    </svg>
                                    
                                    <svg class="img-fluid p-4">
                                        <use xlink:href="img/icon.svg#client1" />
                                    </svg>
                                </div>
                               
                              
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container pt-10 pb-5">
                    <a href="work.php" class="d-flex align-items-center  justify-content-end hover-wh">

                        <div class="hover-wheel1 me-5" data-scroll>
                            <span class="wheel p-2">
                                <svg fill="#000" height="7.5rem" width="7.5rem">
                                    <use xlink:href="img/icon.svg#wheel" />
                                </svg>
                            </span>
    
                            <svg class="rrr" height="3.5rem" width="3.5rem">
                                <use xlink:href="img/icon.svg#r-white" />
                            </svg>
                        </div>

                        <div class="scroll-c ps-4">
                            <span>V</span>
                            <span>V</span>
                            <span>V</span>
                            <span class="pt-1">
                                VER EL TRABAJO <br />
                                CON NUESTROS <br />
                                CLIENTES
                            </span>
                        </div>
                    </a>
                </div>

            </section>
        </div>
    </main>

    <script src="js/bundle.js"></script>
</body>

</html>