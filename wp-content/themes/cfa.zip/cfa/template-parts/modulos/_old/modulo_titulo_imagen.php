<div class="modulo_titulo_imagen">
    <div class="wrap" style="">
        <img src="<?php the_sub_field('imagen_desktop');?>" class="desk" style="max-height:<?php the_sub_field('altura_maxima_desktop');?>">
        <img src="<?php the_sub_field('imagen_mobile');?>" class="mov" style="max-height:<?php the_sub_field('altura_maxima_mobile');?>">
    </div>
</div>